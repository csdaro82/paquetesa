#!/bin/bash

if [ "$(id -u)" != "0" ]; then
        echo "Sorry, you are not root."
        exit 1
fi

/bin/sh /asamblea/programas.sh

/usr/bin/hostnamectl set-hostname ubuntu
/bin/cp -r /asamblea/hosts /etc/hosts
/bin/cp -r /asamblea/puppet.conf /etc/puppet/puppet.conf

/bin/sh /asamblea/freeipa.sh

OLD_HOSTNAME=ubuntu

echo nuevo nombre de la máquina sin dominio:
read NEW_HOSTNAME < /dev/tty

/usr/bin/hostnamectl set-hostname $NEW_HOSTNAME.uio.asambleanacional.gob.ec

echo $NEW_HOSTNAME
if [ -n "$( grep "$OLD_HOSTNAME" /etc/hosts )" ]; then
         sed -i "s/$OLD_HOSTNAME/$NEW_HOSTNAME.uio.asambleanacional.gob.ec $NEW_HOSTNAME/g" /etc/hosts
fi

if [ -n "$( grep "$OLD_HOSTNAME" /etc/puppet/puppet.conf )" ]; then
         sed -i "s/$OLD_HOSTNAME/$NEW_HOSTNAME/g" /etc/puppet/puppet.conf
fi


/usr/sbin/ipa-client-install ipa-client-install --uninstall

/usr/sbin/ipa-client-install --domain=uio.asambleanacional.gob.ec  --server=freeipa.uio.asambleanacional.gob.ec --realm=UIO.ASAMBLEANACIONAL.GOB.EC --principal=admin  --password='Tuv$3lne' --mkhomedir --hostname=$NEW_HOSTNAME.uio.asambleanacional.gob.ec --force-join --ssh-trust-dns --all-ip-addresses -U

/bin/systemctl stop puppet.service

/usr/bin/puppet agent --enable

/usr/bin/puppet agent --test

/usr/bin/puppet cert list

/bin/systemctl start puppet.service

/bin/systemctl enable puppet.service

/bin/systemctl restart puppet.service














