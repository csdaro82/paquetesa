#!/bin/bash
/usr/bin/dconf reset -f /org/mate/desktop/

