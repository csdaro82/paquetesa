#!/bin/bash
/bin/rm -rf /tmp/usuarios.log
who |  cut -d " "   -f 1 | uniq >> /tmp/usuarios.log

      while IFS='' read -r linea || [[ -n "$linea" ]]; do
	             su $linea -c 'export DISPLAY=:0 && notify-send  -i /usr/share/icons/mate/256x256/apps/user-info.png -t 50000 "` cat /tmp/mensaje.txt`"'
		           done < /tmp/usuarios.log

