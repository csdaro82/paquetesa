/bin/cp /asamblea/sources.list /etc/apt/sources.list
/usr/bin/apt-key add /asamblea/repo.asc
/usr/bin/apt-key add /asamblea/libreoffice.asc
/usr/bin/apt-key add /asamblea/nextcloud.gpg

apt update -y
apt dist-upgrade -y
apt install -y \
vim \
wget \
rsync \
okular \
shutter \
gscan2pdf \
gnome-calculator \
gnome-calendar \
vlc \
k3b \
xmind \
master-pdf-editor \
wps-office \
wps-dictionary-installer \
kde-l10n-es \
chromium-browser \
gnome-software \
rar unace p7zip p7zip-full p7zip-rar unrar lzip lhasa arj sharutils mpack lzma lzop \
myspell-es \
ubuntu-restricted-extras libavcodec-extra libdvd-pkg \
nextcloud-client \
puppet
