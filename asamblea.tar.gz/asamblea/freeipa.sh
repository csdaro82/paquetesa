apt-get install -y libsss-sudo freeipa-client cracklib-runtime
#/bin/echo 'session required pam_mkhomedir.so skel=/etc/skel/' >>/etc/pam.d/common-session
/bin/cp /asamblea/common-session /etc/pam.d/common-session
/bin/cp /asamblea/50-ubuntu.conf /usr/share/lightdm/lightdm.conf.d/50-ubuntu.conf
/bin/bash -c "cat > /usr/share/pam-configs/mkhomedir" <<EOF
Name: activate mkhomedir
Default: yes
Priority: 900
Session-Type: Additional
Session:
        required                        pam_mkhomedir.so umask=0022 skel=/etc/skel
EOF
/usr/sbin/pam-auth-update --package mkhomedir


