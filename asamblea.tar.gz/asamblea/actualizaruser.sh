#!/bin/bash

if [ "$(id -u)" != "0" ]; then
        echo "Sorry, you are not root."
        exit 1
fi

echo nombre de la máquina:
read OLD_HOSTNAME < /dev/tty
echo nuevo nombre de la máquina:
read NEW_HOSTNAME < /dev/tty

/usr/bin/hostnamectl set-hostname $NEW_HOSTNAME.uio.asambleanacional.gob.ec


echo $NEW_HOSTNAME
if [ -n "$( grep "$OLD_HOSTNAME" /etc/hosts )" ]; then
	 sed -i "s/$OLD_HOSTNAME/$NEW_HOSTNAME/g" /etc/hosts
fi

if [ -n "$( grep "$OLD_HOSTNAME" /etc/puppet/puppet.conf )" ]; then
	 sed -i "s/$OLD_HOSTNAME/$NEW_HOSTNAME/g" /etc/puppet/puppet.conf
fi

/usr/sbin/ipa-client-install ipa-client-install --uninstall

/usr/sbin/ipa-client-install --domain=uio.asambleanacional.gob.ec  --server=freeipa.uio.asambleanacional.gob.ec --realm=UIO.ASAMBLEANACIONAL.GOB.EC --principal=admin  --password='Tuv$3lne' --mkhomedir --hostname=$NEW_HOSTNAME.uio.asambleanacional.gob.ec --force-join --ssh-trust-dns --all-ip-addresses -U

/usr/bin/puppet cert list

/bin/systemctl restart puppet.service
